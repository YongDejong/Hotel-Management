<?php

// reCAPTCHA v2 Configuration
// Make sure your form uses the reCAPTCHA v2 "I'm not a robot" widget, as these keys are for v2.

define('RECAPTCHA_SITE_KEY', '6LcLF1ErAAAAAGcTNjMjRcdGZEBYkC1qJZSt_nlG');
define('RECAPTCHA_SECRET_KEY', '6LcLF1ErAAAAAGOdVB_J5P0lfeOxAs9PfBes38kt');

// Function to verify reCAPTCHA response
function verifyRecaptcha($recaptcha_response) {
    $url = 'https://www.google.com/recaptcha/api/siteverify';
    $data = array(
        'secret' => RECAPTCHA_SECRET_KEY,
        'response' => $recaptcha_response,
        'remoteip' => $_SERVER['REMOTE_ADDR']
    );

    $options = array(
        'http' => array(
            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($data)
        )
    );

    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    $response = json_decode($result);

    return $response->success;
} 