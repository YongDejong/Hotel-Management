<?php
define('SMTP2GO_API_KEY', 'api-684742AC4E0D48E6A84279FAC6367165'); // Replace with your actual key
define('SMTP_FROM', 'hotelangkor@outlook.com');  // Must be verified in SMTP2Go
define('SMTP_FROM_NAME', 'Hotel Booking');

/*
 * Issues in the original code:
 * 1. No error handling for cURL failures (e.g., network issues, API errors).
 * 2. No check for HTTP status code from cURL.
 * 3. No plain text alternative body (recommended for email deliverability).
 * 4. No "from_name" set in the payload, so sender name may not appear.
 * 5. No reply-to set (optional, but sometimes useful).
 * 6. No validation/sanitization of $to, $subject, $message (though $subject is escaped in HTML).
 * 7. No logging of errors for debugging.
 */

function sendEmail($to, $subject, $message) {
    // Basic validation for $to
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    // Wrap your HTML email nicely
    $htmlMessage = '
    <html>
    <head>
        <title>' . htmlspecialchars($subject) . '</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <h2 style="color: #2c3e50;">' . htmlspecialchars($subject) . '</h2>
            <div style="background: #f8f9fa; padding: 20px; border-radius: 5px;">
                ' . $message . '
            </div>
            <div style="margin-top: 20px; font-size: 12px; color: #666;">
                This is an automated email, please do not reply.
            </div>
        </div>
    </body>
    </html>';

    // Provide a plain text alternative
    $plainMessage = strip_tags(str_replace(['<br>', '<br/>', '<br />'], "\n", $message));

    $data = [
        "api_key" => SMTP2GO_API_KEY,
        "to" => [$to],
        "sender" => SMTP_FROM,
        "sender_name" => SMTP_FROM_NAME,
        "subject" => $subject,
        "html_body" => $htmlMessage,
        "text_body" => $plainMessage
        // Optionally, add "reply_to": [SMTP_FROM]
    ];

    $ch = curl_init("https://api.smtp2go.com/v3/email/send");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

    $response = curl_exec($ch);
    $curlErr = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($curlErr) {
        // Optionally log error: error_log("SMTP2GO cURL error: $curlErr");
        return false;
    }

    if ($httpCode !== 200) {
        // Optionally log error: error_log("SMTP2GO HTTP error: $httpCode, response: $response");
        return false;
    }

    $res = json_decode($response, true);
    return isset($res['data']['succeeded']) && count($res['data']['succeeded']) > 0;
}
