

<?php require "../layouts/header.php"; ?>
<?php require "../../config/config.php"; ?>

<?php 

 if(!isset($_SESSION['adminname'])) {
  echo "<script>window.location.href='".ADMINURL."/admins/login-admins.php';</script>";
 }

 // Fetch all admins
 $admins = $conn->prepare("SELECT * FROM admins");
 $admins->execute();
 $allAdmins = $admins->fetchAll(PDO::FETCH_OBJ);

 // Fetch current admin's position
 $currentAdminPosition = null;
 if (isset($_SESSION['adminname'])) {
    $stmt = $conn->prepare("SELECT position FROM admins WHERE adminname = :adminname LIMIT 1");
    $stmt->execute([':adminname' => $_SESSION['adminname']]);
    $adminData = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($adminData) {
        $currentAdminPosition = $adminData['position'];
    }
 }
?>

      <div class="row">
        <div class="col">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title mb-4 d-inline">Admins</h5>
              <?php if ($currentAdminPosition === 'rec'): ?>
                <a href="javascript:void(0);" class="btn btn-primary mb-4 text-center float-right disabled" tabindex="-1" aria-disabled="true" style="pointer-events: none; opacity: 0.65;">Create Admins</a>
              <?php else: ?>
                <a href="create-admins.php" class="btn btn-primary mb-4 text-center float-right">Create Admins</a>
              <?php endif; ?>
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Adminname</th>
                    <th scope="col">Email</th>
                    <th scope="col">Position</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach($allAdmins as $admin) : ?>
                  <tr>
                    <th scope="row"><?php echo $admin -> id;?> </th>
                    <td><?php echo $admin -> adminname; ?> </td>
                    <td><?php echo $admin -> email; ?> </td>
                    <td><?php echo $admin -> position; ?> </td>
                  </tr>
                <?php endforeach; ?> 
                </tbody>
              </table> 
            </div>
          </div>
        </div>
      </div>



  </div>
<script type="text/javascript">

</script>
</body>
</html>