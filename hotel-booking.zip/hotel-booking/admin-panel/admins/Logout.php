<?php

   session_start();
   session_unset();
   session_destroy();
   header("location: http://www.threeempires.byethost31.com/hotel-booking/admin-panel/admins/login-admins.php"); ?>