<?php require "../layouts/header.php"; ?>
<?php require "../../config/config.php"; ?>


<?php 
if(isset($_SESSION['adminname'])) {
echo "<script>window.location.href='".ADMINURL."';</script>";
}
if (isset($_POST['submit'])) {
if(empty($_POST['email']) OR empty($_POST['password'])) {
  echo "<script>alert('Please fill in all fields');</script>";
 } else {

  $email = $_POST['email'];
  $password = $_POST['password'];

  $login = $conn->query("SELECT * FROM admins WHERE email = '$email'");
  $login->execute();

  $fetch = $login->fetch(PDO::FETCH_ASSOC);

  if($login->rowCount() > 0) {
      if (password_verify($password, $fetch['mypassword'])) {
         //echo "<script>alert('Login successful');</script>";
           $_SESSION['adminname'] = $fetch['adminname'];
           $_SESSION['id'] = $fetch['id'];

          header("location: ".ADMINURL."");
      } else {
          echo "<script>alert('Email or Password is incorrect');</script>";
      }
  } else {
      echo "<script>alert('Email not found');</script>";
  }
 }
}

?>
      <div class="row justify-content-center align-items-center" style="min-height: 80vh;">
        <div class="col-md-6 col-lg-4">
          <div class="card shadow">
            <div class="card-body">
              <h5 class="card-title mt-4 mb-4 text-center">Admin Login</h5>
              <form method="POST" action="login-admins.php">
                  <!-- Email input -->
                  <div class="form-group mb-4">
                    <label for="form2Example1" class="form-label">Email</label>
                    <input type="email" name="email" id="form2Example1" class="form-control" placeholder="Enter your email" required />
                  </div>
                  <!-- Password input -->
                  <div class="form-group mb-4">
                    <label for="form2Example2" class="form-label">Password</label>
                    <input type="password" name="password" id="form2Example2" class="form-control" placeholder="Enter your password" required />
                  </div>
                  <!-- Submit button -->
                  <div class="d-grid">
                    <button type="submit" name="submit" class="btn btn-primary">Login</button>
                  </div>
                </form>
            </div>
          </div>
        </div>
      </div>
                

            </div>
       </div>
<?php require "../layouts/footer.php"; ?>
