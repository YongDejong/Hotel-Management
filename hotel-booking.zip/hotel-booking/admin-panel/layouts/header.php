<?php 
    session_start();
    define("ADMINURL", "http://www.threeempires.byethost31.com/hotel-booking/admin-panel");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="http://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo ADMINURL; ?>/styles/style.css" rel="stylesheet">
    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <style>
        body {
            padding-top: 0;
        }
        #wrapper {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            min-width: 220px;
            max-width: 220px;
            background: #343a40;
            color: #fff;
            min-height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1030;
            padding-top: 56px;
        }
        .sidebar .nav-link {
            color: #fff;
        }
        .sidebar .nav-link.active, .sidebar .nav-link:hover {
            background: #495057;
            color: #fff;
        }
        .main-content {
            margin-left: 220px;
            width: 100%;
            padding-top: 56px;
        }
        @media (max-width: 991.98px) {
            .sidebar {
                position: relative;
                min-width: 100%;
                max-width: 100%;
                min-height: auto;
                padding-top: 0;
            }
            .main-content {
                margin-left: 0;
                padding-top: 0;
            }
        }
    </style>
</head>
<body>
<div id="wrapper">
    <!-- Sidebar -->
    <?php if (isset($_SESSION['adminname'])) : ?>
    <nav class="sidebar d-none d-lg-block">
        <div class="sidebar-sticky">
            <a class="navbar-brand d-block py-3 px-3" href="<?php echo ADMINURL; ?>" style="color:#fff;font-weight:bold;">Angkor Hotel Admin Panel</a>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link<?php if(basename($_SERVER['PHP_SELF']) == 'index.php') echo ' active'; ?>" href="<?php echo ADMINURL; ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo ADMINURL; ?>/admins/admins.php">Admins</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo ADMINURL; ?>/hotels-admins/show-hotels.php">Hotels</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo ADMINURL; ?>/rooms-admins/show-rooms.php">Rooms</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo ADMINURL; ?>/bookings-admins/show-bookings.php">Bookings</a>
                </li>
                <li class="nav-item mt-3">
                    <div class="dropdown px-3">
                        <a class="nav-link dropdown-toggle" href="#" id="sidebarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color:#fff;">
                            <?php echo $_SESSION['adminname']; ?>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="sidebarDropdown">
                            <a class="dropdown-item" href="<?php echo ADMINURL; ?>/admins/logout.php">Logout</a>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
    <?php endif; ?>

    <!-- Top Navbar for small screens and login/logout -->
    <nav class="navbar header-top fixed-top navbar-expand-lg navbar-dark bg-dark d-lg-none">
        <div class="container">
            <a class="navbar-brand" href="<?php echo ADMINURL; ?>">Angkor Hotel Admin Panel</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTextMobile" aria-controls="navbarTextMobile"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTextMobile">
                <ul class="navbar-nav mr-auto">
                    <?php if (isset($_SESSION['adminname'])) : ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo ADMINURL; ?>">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo ADMINURL; ?>/admins/admins.php">Admins</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo ADMINURL; ?>/hotels-admins/show-hotels.php">Hotels</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo ADMINURL; ?>/rooms-admins/show-rooms.php">Rooms</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo ADMINURL; ?>/bookings-admins/show-bookings.php">Bookings</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMobile" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php echo $_SESSION['adminname']; ?>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdownMobile">
                                <a class="dropdown-item" href="<?php echo ADMINURL; ?>/admins/logout.php">Logout</a>
                            </div>
                        </li>
                    <?php else : ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo ADMINURL; ?>/admins/login-admins.php">Login</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <?php if (!isset($_SESSION['adminname'])): ?>
            <nav class="navbar header-top navbar-expand-lg navbar-dark bg-dark d-none d-lg-block">
                <div class="container">
                    <a class="navbar-brand" href="<?php echo ADMINURL; ?>">Angkor Hotel Admin Panel</a>
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo ADMINURL; ?>/admins/login-admins.php">Login</a>
                        </li>
                    </ul>
                </div>
            </nav>
        <?php endif; ?>
        <div class="container-fluid">