<?php require "includes/header.php";?>


    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/image_2.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          	<p class="breadcrumbs mb-2"><span class="mr-2"><a href="index.php">Home <i class="fa fa-chevron-right"></i></a></span> <span>Contact <i class="fa fa-chevron-right"></i></span></p>
            <h1 class="mb-0 bread">Contact Us</h1>
          </div>
        </div>
      </div>
    </section>
   
   	<section class="ftco-section bg-light">
    	<div class="container">
    		<div class="row no-gutters">
    			<div class="col-md-8">
    				<div id="map" class="map"></div>
    			</div>
    			<div class="col-md-4 p-4 p-md-5 bg-white">
    				<h2 class="font-weight-bold mb-4">Lets get started</h2>
    				<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
    				<p><a href="index.php#hotel-rooms" class="btn btn-primary">Book Apartment Now</a></p>
    			</div>
					<div class="col-md-12">
						<div class="wrapper">
							<div class="row no-gutters">
								<div class="col-lg-8 col-md-7 d-flex align-items-stretch">
									<div class="contact-wrap w-100 p-md-5 p-4">
										<h3 class="mb-4">Get in touch</h3>
										<div id="form-message-warning" class="mb-4"></div> 
					      		<div id="form-message-success" class="mb-4">
					            Your message was sent, thank you!
					      		</div>
										<form method="POST" id="contactForm" name="contactForm" class="contactForm">
											<div class="row">
												<div class="col-md-6">
													<div class="form-group">
														<label class="label" for="name">Full Name</label>
														<input type="text" class="form-control" name="name" id="name" placeholder="Name">
													</div>
												</div>
												<div class="col-md-6"> 
													<div class="form-group">
														<label class="label" for="email">Email Address</label>
														<input type="email" class="form-control" name="email" id="email" placeholder="Email">
													</div>
												</div>
												<div class="col-md-12">
													<div class="form-group">
														<label class="label" for="subject">Subject</label>
														<input type="text" class="form-control" name="subject" id="subject" placeholder="Subject">
													</div>
												</div>
												<div class="col-md-12">
													<div class="form-group">
														<label class="label" for="#">Message</label>
														<textarea name="message" class="form-control" id="message" cols="30" rows="4" placeholder="Message"></textarea>
													</div>
												</div>
												<div class="col-md-12">
													<div class="form-group">
														<input type="submit" name="submit" value="Send Message" class="btn btn-primary">
														<div class="submitting"></div>
														<?php
														if(isset($_POST['submit'])) {
															// Get form data
															$name = isset($_POST['name']) ? trim($_POST['name']) : '';
															$email = isset($_POST['email']) ? trim($_POST['email']) : '';
															$subject = isset($_POST['subject']) ? trim($_POST['subject']) : '';
															$message = isset($_POST['message']) ? trim($_POST['message']) : '';

															// Validate inputs
															if(empty($name) || empty($email) || empty($subject) || empty($message)) {
																echo "<script>
																	alert('Please fill in all fields');
																	window.location.href='index.php';
																</script>";
																exit;
															}

															// Email settings
															$to = "khmerdamrong107@gmail.com";
															$email_message = "Name: $name\n";
															$email_message .= "Email: $email\n";
															$email_message .= "Subject: $subject\n\n";
															$email_message .= "Message:\n$message";
															$headers = "From: $email";

															// Try to send email
															if(@mail($to, $subject, $email_message, $headers)) {
																echo "<script>
																	window.location.href='index.php';
																</script>";
																exit;
															} else {
																echo "<script>
																	alert('Failed to send message. Please try again later.');
																	window.location.href='index.php';
																</script>";
																exit;
															}
														}
														?>
													</div>
												</div>
											</div>
										</form>
									</div>
								</div>
								<div class="col-lg-4 col-md-5 d-flex align-items-stretch">
									<div class="info-wrap bg-primary w-100 p-md-5 p-4">
										<h3>Let's get in touch</h3>
										<p class="mb-4">We're open for any suggestion or just to have a chat</p>
					        	<div class="dbox w-100 d-flex align-items-start">
					        		<div class="icon d-flex align-items-center justify-content-center">
					        			<span class="fa fa-map-marker"></span>
					        		</div>
					        		<div class="text pl-3">
						            <p><span>Address:</span> Russian Federation Blvd (110), Phnom Penh 120404</p>
						          </div>
					          </div>
					        	<div class="dbox w-100 d-flex align-items-center">
					        		<div class="icon d-flex align-items-center justify-content-center">
					        			<span class="fa fa-phone"></span>
					        		</div>
					        		<div class="text pl-3">
						            <p><span>Phone:</span> <a href="tel://1234567920">071 698 6872</a></p>
						          </div>
					          </div>
					        	<div class="dbox w-100 d-flex align-items-center">
					        		<div class="icon d-flex align-items-center justify-content-center">
					        			<span class="fa fa-paper-plane"></span>
					        		</div>
					        		<div class="text pl-3">
						            <p><span>Email:</span> <a href="mailto:info@yoursite.com">AngkorHotels@outlook.com</a></p>
						          </div>
					          </div>
						          </div>
					          </div>
				          </div>
								</div>
							</div>
						</div>
					</div>
				</div>
    	</div>
    </section>
		
<?php require "includes/footer.php";?>
