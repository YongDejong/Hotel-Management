<?php require "includes/header.php";?>
<?php require "config/config.php";?>

<?php 
	//hotels
	$hotels = $conn->query("SELECT * FROM hotels WHERE status = 1 ");
	$hotels->execute();
	$allHotels = $hotels->fetchAll(PDO::FETCH_OBJ);

	//rooms
	$rooms = $conn->query("SELECT * FROM rooms WHERE status = 1 ");
	$rooms->execute();
	$allRooms = $rooms->fetchAll(PDO::FETCH_OBJ);


?>

    <div class="hero-wrap js-fullheight" style="background-image: url('images/image_2.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start" data-scrollax-parent="true">
          <div class="col-md-7 ftco-animate">
          	<h2 class="subheading">Welcome to Angkor Hotel</h2>
          	<h1 class="mb-4">Rooms Made for Memories</h1>
            <p>
              <a href="#hotel-rooms" class="btn btn-primary" id="scroll-to-rooms">Book Now</a>
              <a href="<?php echo APPURL;?>/contact.php" class="btn btn-white">Contact us</a>
            </p>
            <script>
              document.addEventListener('DOMContentLoaded', function() {
                var scrollBtn = document.getElementById('scroll-to-rooms');
                if (scrollBtn) {
                  scrollBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    var target = document.getElementById('hotel-rooms');
                    if (target) {
                      target.scrollIntoView({ behavior: 'smooth' });
                    }
                  });
                }
              });
            </script>
          </div>
        </div>
      </div>
    </div>
        </div>
    	</div>
    </section>

    <section class="ftco-section bg-light" id="hotel-rooms">
			<div class="container-fluid px-md-0">
				<div class="row no-gutters justify-content-center pb-5 mb-3">
          <div class="col-md-7 heading-section text-center ftco-animate">
            <h2>Your Perfect Stay Begins Here</h2>
          </div>
        </div>
				<div class="row no-gutters">
					<?php foreach ($allRooms as $rooms) :  ?>
    			<div class="col-lg-6">
    				<div class="room-wrap d-md-flex">
    					<a href="#" class="img" style="background-image: url(images/<?php echo $rooms->image; ?>);"></a>
    					<div class="half left-arrow d-flex align-items-center">
    						<div class="text p-4 p-xl-5 text-center">
    							<p class="star mb-0"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span></p>
    							<!-- 	<p class="mb-0"><span class="price mr-1">$120.00</span> <span class="per">per night</span></p> -->
	    						<h3 class="mb-3"><a href="<?php echo APPURL;?>/rooms/room-single.php?id=<?php echo $rooms->id; ?>"><?php echo $rooms->name; ?></a></h3>
	    						<ul class="list-accomodation">
	    							<li><span>Max:</span> <?php echo $rooms->num_persons; ?> Persons</li>
	    							<li><span>Size:</span> <?php echo $rooms->size; ?> m2</li>
	    							<li><span>View:</span> <?php echo $rooms->view; ?></li>
	    							<li><span>Bed:</span> <?php echo $rooms->num_beds; ?></li>
									<li><span>Price Per Night:</span>$ <?php echo $rooms->price; ?></li>

	    						</ul>
	    						<p class="pt-1"><a href="<?php echo APPURL;?>/rooms/room-single.php?id=<?php echo $rooms->id; ?>" class="btn-custom px-3 py-2">View Room Details <span class="icon-long-arrow-right"></span></a></p>
    						</div>
    					</div>
    				</div>
    			</div>
    			<?php endforeach;?>
    		</div>
			</div>
		</section>



    <section class="ftco-section bg-light">
			<div class="container">
				<div class="row no-gutters">
					<div class="col-md-6 wrap-about">
						<div class="img img-2 mb-4">
							<img src="<?php echo APPURL;?>/images/restuarant.jpg" alt="Restaurant" style="width:100%;height:auto;display:block;">
						</div>
						
					</div>
					<div class="col-md-6 wrap-about ftco-animate">
	          <div class="heading-section">
	          	<div class="pl-md-5">
		            <h2 class="mb-2">What we offer</h2>
	            </div>
	          </div>
	          <div class="pl-md-5">
							<p>A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.</p>
							<div class="row">
		            <div class="services-2 col-lg-6 d-flex w-100">
		              <div class="icon d-flex justify-content-center align-items-center">
		            		<span class="flaticon-diet"></span>
		              </div>
		              <div class="media-body pl-3">
		                <h3 class="heading">Breakfast</h3>
		                <p>Wake Up to a Delicious Free Breakfast in Our Elegant Restaurant(2 people)</p>
		              </div>
		            </div> 
		            <div class="services-2 col-lg-6 d-flex w-100">
		              <div class="icon d-flex justify-content-center align-items-center">
		            		<span class="flaticon-workout"></span>
		              </div>
		              <div class="media-body pl-3">
		                <h3 class="heading">Hot Showers</h3>
		                <p>A small river named Duden flows by their place and supplies it with the necessary</p>
		              </div>
		            </div>
		            <div class="services-2 col-lg-6 d-flex w-100">
		              <div class="icon d-flex justify-content-center align-items-center">
		            		<span class="flaticon-diet-1"></span>
		              </div>
		              <div class="media-body pl-3">
		                <h3 class="heading">Fitness</h3>
		                <p>Stay active during your stay with access to our modern fitness facilities.</p>
		              </div>
		            </div>      
		            <div class="services-2 col-lg-6 d-flex w-100">
		              <div class="icon d-flex justify-content-center align-items-center">
		            		<span class="flaticon-first"></span>
		              </div>
		              <div class="media-body pl-3">
		                <h3 class="heading">Air Conditioning</h3>
		                <p>A small river named Duden flows by their place and supplies it with the necessary</p>
		              </div>
		            </div>
		            <div class="services-2 col-lg-6 d-flex w-100">
		              <div class="icon d-flex justify-content-center align-items-center">
		            		<span class="flaticon-first"></span>
		              </div>
		              <div class="media-body pl-3">
		                <h3 class="heading">Free Wifi</h3>
		                <p>A small river named Duden flows by their place and supplies it with the necessary</p>
		              </div>
		            </div> 
		            <div class="services-2 col-lg-6 d-flex w-100">
		              <div class="icon d-flex justify-content-center align-items-center">
		            		<span class="flaticon-first"></span>
		              </div>
		              <div class="media-body pl-3">
		                <h3 class="heading">Kitchen</h3>
		                <p>A small river named Duden flows by their place and supplies it with the necessary</p>
		              </div>
		            </div> 
		            <div class="services-2 col-lg-6 d-flex w-100">
		              <div class="icon d-flex justify-content-center align-items-center">
		            		<span class="flaticon-first"></span>
		              </div>
		              <div class="media-body pl-3">
		                <h3 class="heading">Ironing</h3>
		                <p>A small river named Duden flows by their place and supplies it with the necessary</p>
		              </div>
		            </div> 
		            <div class="services-2 col-lg-6 d-flex w-100">
		              <div class="icon d-flex justify-content-center align-items-center">
		            		<span class="flaticon-first"></span>
		              </div>
		              <div class="media-body pl-3">
		                <h3 class="heading">Lovkers</h3>
		                <p>A small river named Duden flows by their place and supplies it with the necessary</p>
		              </div>
		            </div>
		          </div>  
						</div>
					</div>
				</div>
			</div>
		</section>
		
		<section class="ftco-intro" style="background-image: url(images/image_2.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-md-9 text-center">
						<h2>Ready to get started</h2>
						<p class="mb-4">It's safe to book online with us! Get your dream stay in clicks or drop us a line with your questions.</p>
						<p class="mb-0"><a href="<?php echo APPURL;?>/about.php" class="btn btn-primary px-4 py-3">Learn More</a> <a href="<?php echo APPURL;?>/contact.php" class="btn btn-white px-4 py-3">Contact us</a></p>
					</div>
				</div>
			</div>
		</section>

<?php require "includes/footer.php"; ?>