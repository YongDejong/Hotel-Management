<?php



    session_start();
    session_unset(); // Unset all session variables
    session_destroy(); // Destroy the session

    header("location: http://www.threeempires.byethost31.com/hotel-booking/login.php"); // Redirect to login page
