<?php require "../includes/header.php"; ?>
<?php require "../config/config.php"; ?>
<?php require "../config/email_config.php"; ?>
<?php 

if(isset($_SESSION['username'])) {
    echo "<script>window.location.href='".APPURL."';</script>";
}

if(isset($_POST['submit'])) {
    if(empty($_POST['email'])) {
        echo "<script>alert('Please enter your email');</script>";
    } else {
        $email = $_POST['email'];
        
        // Check if email exists
        $check = $conn->query("SELECT * FROM users WHERE email = '$email'");
        $check->execute();

        if($check->rowCount() > 0) {
            // Generate reset token
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            // Store reset token in database
            $update = $conn->prepare("UPDATE users SET reset_token = ?, reset_expires = ? WHERE email = ?");
            $update->execute([$token, $expires, $email]);

            // Send reset email
            $reset_link = APPURL . "/auth/reset-password.php?token=" . $token;
            $subject = "Password Reset Request";
            $message = '
                <p>Hello,</p>
                <p>We received a request to reset your password. Click the button below to reset it:</p>
                <p style="text-align: center;">
                    <a href="' . $reset_link . '" style="display: inline-block; padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">Reset Password</a>
                </p>
                <p>If you did not request this password reset, please ignore this email.</p>
                <p>This link will expire in 1 hour for security reasons.</p>
                <p>Best regards,<br>Hotel Booking Team</p>';

            if(sendEmail($email, $subject, $message)) {
                echo "<script>alert('Password reset instructions have been sent to your email');</script>";
            } else {
                echo "<script>alert('Error sending email. Please try again later.');</script>";
            }
        } else {
            echo "<script>alert('Email not found');</script>";
        }
    }
}

?>

    <div class="hero-wrap js-fullheight" style="background-image: url('<?php echo APPURL; ?>/images/image_2.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start" data-scrollax-parent="true">
          <div class="col-md-7 ftco-animate">
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section ftco-book ftco-no-pt ftco-no-pb">
    	<div class="container">
	    	<div class="row justify-content-middle" style="margin-left: 397px;">
	    		<div class="col-md-6 mt-5">
						<form action="forgot-password.php" method="POST" class="appointment-form" style="margin-top: -568px;">
							<h3 class="mb-3">Forgot Password</h3>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
			    					    <input type="text" name="email" class="form-control" placeholder="Enter your email">
			    				    </div>
								</div>
								
								<div class="col-md-12">
                                    <div class="form-group">
                                        <input type="submit" name="submit" value="Reset Password" class="btn btn-primary py-3 px-4">
                                    </div>
								</div>
                                <div class="col-md-12 text-center">
                                    <div class="form-group">
                                        <a href="login.php" class="text-primary">Back to Login</a>
                                    </div>
								</div>
							</div>
	    			</form>
	    		</div>
	    	</div>
	    </div>
    </section>

<?php require "../includes/footer.php"; ?> 