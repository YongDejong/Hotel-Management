<?php require "../includes/header.php"; ?>
<?php require "../config/config.php"; ?>
<?php require "../config/email_config.php"; ?>
<?php require "../config/recaptcha_config.php"; ?>
<?php 

if(isset($_SESSION['username'])) {
    echo "<script>window.location.href='".APPURL."';</script>";
    exit;
}

// If a reset token is present in the URL, redirect to reset-password.php
if (isset($_GET['token']) && !empty($_GET['token'])) {
    $token = urlencode($_GET['token']);
    echo "<script>window.location.href='".APPURL."/auth/reset-password.php?token={$token}';</script>";
    exit;
}

if(isset($_POST['submit'])) {
    if(empty($_POST['email'])) {
        echo "<script>alert('Please enter your email');</script>";
    } else if(!isset($_POST['g-recaptcha-response']) || empty($_POST['g-recaptcha-response'])) {
        echo "<script>alert('Please complete the CAPTCHA verification');</script>";
    } else {
        // Verify reCAPTCHA response
        $recaptcha_response = $_POST['g-recaptcha-response'];
        if(verifyRecaptcha($recaptcha_response)) {
            $email = $_POST['email'];
            
            // Check if email exists
            $check = $conn->prepare("SELECT * FROM users WHERE email = ?");
            $check->execute([$email]);

            if($check->rowCount() > 0) {
                // Generate reset token
                $token = bin2hex(random_bytes(32));
                $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
                
                // Store reset token in database
                $update = $conn->prepare("UPDATE users SET reset_token = ?, reset_expires = ? WHERE email = ?");
                $update->execute([$token, $expires, $email]);

                // Send reset email
                $reset_link = APPURL . "/auth/reset-password.php?token=" . $token;
                $subject = "Password Reset Request";
                $message = '
                    <p>Hello,</p>
                    <p>We received a request to reset your password. Click the button below to reset it:</p>
                    <p style="text-align: center;">
                        <a href="' . $reset_link . '" style="display: inline-block; padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">Reset Password</a>
                    </p>
                    <p>If you did not request this password reset, please ignore this email.</p>
                    <p>This link will expire in 1 hour for security reasons.</p>
                    <p>Best regards,<br>Hotel Booking Team</p>';

                if(!sendEmail($email, $subject, $message)) {
                    echo "<script>alert('Error sending email. Please try again later.');</script>";
                } else {
                    echo "<script>alert('Password reset instructions have been sent to your email');</script>";
                }
            } else {
                echo "<script>alert('Email not found');</script>";
            }
        } else {
            echo "<script>alert('CAPTCHA verification failed. Please try again.');</script>";
        }
    }
}

?>

<div class="hero-wrap js-fullheight" style="background-image: url('<?php echo APPURL; ?>/images/image_2.jpg');" data-stellar-background-ratio="0.5">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start" data-scrollax-parent="true">
      <div class="col-md-7 ftco-animate">
      </div>
    </div>
  </div>
</div>

<script src="https://www.google.com/recaptcha/api.js" async defer></script>

<section class="ftco-section ftco-book ftco-no-pt ftco-no-pb">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-sm-10 col-md-8 col-lg-6 mt-5">
                <form action="forgot-password.php" method="POST" class="appointment-form" style="margin-top: -568px;">
                    <h3 class="mb-3 text-center">Forgot Password</h3>
                    <div class="row">
                        <div class="col-12 mb-3">
                            <div class="form-group">
                                <input type="email" name="email" class="form-control" placeholder="Enter your email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <div class="g-recaptcha" data-sitekey="<?php echo RECAPTCHA_SITE_KEY; ?>"></div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <input type="submit" name="submit" value="Reset Password" class="btn btn-primary py-3 px-4 w-100" onclick="setTimeout(function(){ window.location.href='login.php'; }, 100);">
                            </div>
                        </div>
                        <div class="col-12 text-center">
                            <div class="form-group">
                                <a href="login.php" class="text-primary">Back to Login</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<style>
@media (max-width: 991.98px) {
    .appointment-form {
        margin-top: 0 !important;
    }
    .hero-wrap .container {
        padding-left: 15px;
        padding-right: 15px;
    }
}
@media (max-width: 767.98px) {
    .appointment-form {
        margin-top: 0 !important;
        padding: 20px 10px;
    }
    .ftco-section .container {
        padding-left: 0;
        padding-right: 0;
    }
}
@media (max-width: 575.98px) {
    .appointment-form {
        margin-top: 0 !important;
        padding: 10px 0;
    }
    .ftco-section .container {
        padding-left: 0;
        padding-right: 0;
    }
}
</style>

<?php require "../includes/footer.php"; ?> 