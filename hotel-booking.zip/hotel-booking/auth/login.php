<?php require "../includes/header.php"; ?>
<?php require "../config/config.php"; ?>
<?php 

  if(isset($_SESSION['username'])) {
    echo "<script>window.location.href='".APPURL."';</script>";
  } 


if (isset($_POST['submit'])) {
	if(empty($_POST['email']) OR empty($_POST['password'])) {
		echo "<script>alert('Please fill in all fields');</script>";
	} else {

    $email = $_POST['email'];
    $password = $_POST['password'];

    $login = $conn->query("SELECT * FROM users WHERE email = '$email'");
    $login->execute();

    $fetch = $login->fetch(PDO::FETCH_ASSOC);

    if($login->rowCount() > 0) {

      if(password_verify($password, $fetch['mypassword'])) {

        //echo "<script>alert('Login successful');</script>";

          $_SESSION['username'] = $fetch['username'];
          $_SESSION['id'] = $fetch['id'];

          header("location: ".APPURL."");

      } else {

        echo "<script>alert('Email or Password is incorrect');</script>";
      }
    } else {
        echo "<script>alert('Email not found');</script>";
    }
   }
  }


?>

    <div class="hero-wrap js-fullheight" style="background-image: url('<?php echo APPURL; ?>/images/image_2.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start" data-scrollax-parent="true">
          <div class="col-md-7 ftco-animate">
          	<!-- <h2 class="subheading">Welcome to Vacation Rental</h2>
          	<h1 class="mb-4">Rent an appartment for your vacation</h1>
            <p><a href="#" class="btn btn-primary">Learn more</a> <a href="#" class="btn btn-white">Contact us</a></p> -->
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section ftco-book ftco-no-pt ftco-no-pb">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-sm-10 col-md-8 col-lg-6 mt-5">
                    <form action="login.php" method="POST" class="appointment-form p-4 p-md-5 shadow rounded bg-white">
                        <h3 class="mb-3 text-center">Login</h3>
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <input type="text" name="email" class="form-control" placeholder="Email" autocomplete="username" required>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <input type="password" name="password" class="form-control" placeholder="Password" autocomplete="current-password" required>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group mb-0">
                                    <input type="submit" name="submit" value="Login" class="btn btn-primary py-3 px-4 w-100">
                                </div>
                            </div>
                            <div class="col-12 text-center mt-3">
                                <div class="form-group mb-0">
                                    <a href="forgot-password.php" class="text-primary">Forgot Password?</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <style>
            @media (max-width: 767.98px) {
                .appointment-form {
                    margin-top: 0 !important;
                    padding: 2rem 1rem !important;
                }
            }
        </style>
    </section>

    <?php require "../includes/footer.php"; ?>