<?php require "../includes/header.php"; ?>
<?php require "../config/config.php"; ?>
<?php require "../config/recaptcha_config.php"; ?>
<?php 


if(isset($_SESSION['username'])) {
	echo "<script>window.location.href='".APPURL."';</script>";
}

if (isset($_POST['submit'])) {
	if(empty($_POST['username']) OR empty($_POST['email']) OR empty($_POST['password'])) {
		echo "<script>alert('Please fill in all fields');</script>";
	} else if(!isset($_POST['g-recaptcha-response']) || empty($_POST['g-recaptcha-response'])) {
        echo "<script>alert('Please complete the CAPTCHA verification');</script>";
    } else {
        // Verify reCAPTCHA response
        $recaptcha_response = $_POST['g-recaptcha-response'];
        if(verifyRecaptcha($recaptcha_response)) {
            $username = $_POST['username'];
            $email = $_POST['email'];
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            
            $insert = $conn->prepare("INSERT INTO users (username, email, mypassword) 
            VALUES (:username, :email, :mypassword)");

            $insert->execute([
                ":username" => $username,
                ":email" => $email,
                ":mypassword" => $password,
            ]);

            header("location: login.php");
        } else {
            echo "<script>alert('CAPTCHA verification failed. Please try again.');</script>";
        }
	}
}



?>

    <div class="hero-wrap js-fullheight" style="background-image: url('<?php echo APPURL; ?>/images/image_2.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start" data-scrollax-parent="true">
          <div class="col-md-7 ftco-animate">
            <!-- <h2 class="subheading">Welcome to Vacation Rental</h2>
            <h1 class="mb-4">Rent an appartment for your vacation</h1>
            <p><a href="#" class="btn btn-primary">Learn more</a> <a href="#" class="btn btn-white">Contact us</a></p> -->
          </div>
        </div>
      </div>
    </div>

    <!-- Add reCAPTCHA script in the head section -->
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>

    <section class="ftco-section ftco-book ftco-no-pt ftco-no-pb">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-sm-10 col-md-8 col-lg-6 mt-5">
                    <form action="register.php" method="POST" class="appointment-form p-4 p-md-5 shadow rounded bg-white">
                        <h3 class="mb-3 text-center">Register</h3>
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <input type="text" name="username" class="form-control" placeholder="Username" required>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <input type="text" name="email" class="form-control" placeholder="Email" required>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <input type="password" name="password" class="form-control" placeholder="Password" required>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <!-- Add reCAPTCHA widget -->
                                    <div class="g-recaptcha" data-sitekey="<?php echo RECAPTCHA_SITE_KEY; ?>"></div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group mb-0">
                                    <input type="submit" name="submit" value="Register" class="btn btn-primary py-3 px-4 w-100">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <style>
            @media (max-width: 767.98px) {
                .appointment-form {
                    margin-top: 0 !important;
                    padding: 2rem 1rem !important;
                }
            }
        </style>
    </section>

 <?php require "../includes/footer.php"; ?>