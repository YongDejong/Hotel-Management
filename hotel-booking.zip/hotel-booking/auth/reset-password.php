<?php require "../includes/header.php"; ?>
<?php require "../config/config.php"; ?>

<?php
// Redirect logged-in users away from reset page
if (isset($_SESSION['username'])) {
    echo "<script>window.location.href='" . APPURL . "';</script>";
    exit;
}

// Check for token in URL
if (!isset($_GET['token']) || empty($_GET['token'])) {
    echo "<script>window.location.href='" . APPURL . "/auth/login.php';</script>";
    exit;
}

$token = $_GET['token'];

// Validate token: must be 64 hex chars (from bin2hex(random_bytes(32)))
if (!preg_match('/^[a-f0-9]{64}$/', $token)) {
    echo "<script>alert('Invalid reset token format.'); window.location.href='" . APPURL . "/auth/login.php';</script>";
    exit;
}

// Verify token and check if it's expired
$check = $conn->prepare("SELECT * FROM users WHERE reset_token = ? AND reset_expires > NOW()");
$check->execute([$token]);
$user = $check->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "<script>alert('Invalid or expired reset token'); window.location.href='" . APPURL . "/auth/login.php';</script>";
    exit;
}

if (isset($_POST['submit'])) {
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    if (empty($password) || empty($confirm_password)) {
        echo "<script>alert('Please fill in all fields');</script>";
    } elseif ($password !== $confirm_password) {
        echo "<script>alert('Passwords do not match');</script>";
    } elseif (strlen($password) < 8) {
        echo "<script>alert('Password must be at least 8 characters long');</script>";
    } else {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Update password and clear reset token
        $update = $conn->prepare("UPDATE users SET mypassword = ?, reset_token = NULL, reset_expires = NULL WHERE id = ?");
        $update->execute([$hashedPassword, $user['id']]);

        // Optional: Unset session variables if any, for extra security
        // session_unset();

        echo "<script>alert('Password has been reset successfully'); window.location.href='" . APPURL . "/auth/login.php';</script>";
        exit;
    }
}
?>

<div class="hero-wrap js-fullheight" style="background-image: url('<?php echo APPURL; ?>/images/image_2.jpg');" data-stellar-background-ratio="0.5">
  <div class="overlay"></div>
  <div class="container">
    <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start" data-scrollax-parent="true">
      <div class="col-md-7 ftco-animate">
      </div>
    </div>
  </div>
</div>

<section class="ftco-section ftco-book ftco-no-pt ftco-no-pb">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-sm-10 col-md-8 col-lg-6 mt-5">
                <form action="" method="POST" class="appointment-form" style="margin-top: -568px;" autocomplete="off">
                    <h3 class="mb-3 text-center">Reset Password</h3>
                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <input type="password" name="password" class="form-control" placeholder="New Password" minlength="8" required autocomplete="new-password">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <input type="password" name="confirm_password" class="form-control" placeholder="Confirm New Password" minlength="8" required autocomplete="new-password">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group d-flex justify-content-center">
                                <input type="submit" name="submit" value="Reset Password" class="btn btn-primary py-3 px-4 w-100">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<style>
@media (max-width: 991.98px) {
    .appointment-form {
        margin-top: 0 !important;
    }
    .hero-wrap .container {
        padding-left: 15px;
        padding-right: 15px;
    }
}
@media (max-width: 767.98px) {
    .appointment-form {
        margin-top: 0 !important;
        padding: 20px 10px;
    }
    .ftco-section .container {
        padding-left: 0;
        padding-right: 0;
    }
}
@media (max-width: 575.98px) {
    .appointment-form {
        margin-top: 0 !important;
        padding: 10px 0;
    }
    .ftco-section .container {
        padding-left: 0;
        padding-right: 0;
    }
}
</style>

<?php require "../includes/footer.php"; ?> 