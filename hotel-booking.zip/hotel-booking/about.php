<?php require "includes/header.php";?>
<?php require "config/config.php";?>

    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/image_2.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          	<p class="breadcrumbs mb-2"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>About us <i class="ion-ios-arrow-forward"></i></span></p>
            <h1 class="mb-0 bread">About Us</h1>
          </div>
        </div>
      </div>
    </section>
   
    <section class="ftco-section bg-light">
    	<div class="container">
    		<div class="row">
          <div class="col-md-4 d-flex services align-self-stretch px-4 ftco-animate">
            <div class="d-block services-wrap text-center">
              <div class="img" style="background-image: url(images/services-1.jpg);"></div>
              <div class="media-body py-4 px-3">
                <h3 class="heading">Map Direction</h3>
                <p>Find us easily and get directions to our location.</p>
                <p><a href="contact.php#contact-section" class="btn btn-primary">Read more</a></p>
              </div>
            </div>      
          </div>
          <div class="col-md-4 d-flex services align-self-stretch px-4 ftco-animate">
            <div class="d-block services-wrap text-center">
              <div class="img" style="background-image: url(images/services-2.jpg);"></div>
              <div class="media-body py-4 px-3">
                <h3 class="heading">Accomodation Services</h3>
                <p>Comfortable rooms, great service, and everything you need for a perfect stay.</p>
                <p><a href="index.php#hotel-rooms" class="btn btn-primary">Read more</a></p>
              </div>
            </div>    
          </div>
          <div class="col-md-4 d-flex services align-self-stretch px-4 ftco-animate">
            <div class="d-block services-wrap text-center">
              <div class="img" style="background-image: url(images/image_2.jpg);"></div>
              <div class="media-body py-4 px-3">
                <h3 class="heading">Great Experience</h3>
                <p>Discover real experiences from our guests and find out why they love staying at Angkor Hotel.</p>
                <p><a href="#testimonials" class="btn btn-primary" id="scroll-to-testimonials">Read more</a></p>
                <script>
                  document.addEventListener('DOMContentLoaded', function() {
                    var scrollBtn = document.getElementById('scroll-to-testimonials');
                    if (scrollBtn) {
                      scrollBtn.addEventListener('click', function(e) {
                        e.preventDefault();
                        var target = document.getElementById('testimonials');
                        if (target) {
                          target.scrollIntoView({ behavior: 'smooth' });
                        }
                      });
                    }
                  });
                </script>
              </div>
            </div>      
          </div>
        </div>
    	</div>
    </section>


    <section id="testimonials" class="ftco-section testimony-section bg-light">
      <div class="container">
        <div class="row justify-content-center pb-5 mb-3">
          <div class="col-md-7 heading-section text-center ftco-animate">
            <h2>Happy Clients & Feedbacks</h2>
          </div>
        </div>
        <div class="row ftco-animate">
          <div class="col-md-12">
            <div class="carousel-testimony owl-carousel">
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/damrong.jpg)">
                  </div>
                  <div class="text pl-4">
                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="fa fa-quote-left"></i>
                    </span>
                    <p>សេវាកម្មនៅសណ្ឋាគារនេះល្អណាស់ ខ្ញុំទទួលបានការថែទាំយ៉ាងប្រុងប្រយ័ត្ន និងរហ័ស</p>
                    <p class="name">ហេង ដាំរ៉ុង</p>
                    <span class="position">Group Leader</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/kimhak.jpg)">
                  </div>
                  <div class="text pl-4">
                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="fa fa-quote-left"></i>
                    </span>
                    <p>សេវាកម្មរបស់សណ្ឋាគារមានល្បឿនលឿន និងមានគុណភាពខ្ពស់។</p>
                    <p class="name">អន គឹមហាក់</p>
                    <span class="position">Member(Handle Designing)</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/Kosal.jpg)">
                  </div>
                  <div class="text pl-4">
                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="fa fa-quote-left"></i>
                    </span>
                    <p>សេវាកម្មគាំទ្រភ្ញៀវកំពុងស្វាគមន៍ និងរហ័ស។</p>
                    <p class="name">អាន ច័ន្ទកុសល</p>
                    <span class="position">Member (Handle Coding)</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/chhuet.jpg)">
                  </div>
                  <div class="text pl-4">
                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="fa fa-quote-left"></i>
                    </span>
                    <p>ខ្ញុំពេញចិត្តនឹងជម្រើសអាហារឆ្ងាញ់ៗ និងចម្រុះ</p>
                    <p class="name">ម៉ៃ ឆើត</p>
                    <span class="position">Member (Handle Coding)</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/Teacher.jpg)">
                  </div>
                  <div class="text pl-4">
                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="fa fa-quote-left"></i>
                    </span>
                    <p>បុគ្គលិកមានភាពរួសរាយរាក់ទាក់ និងជួយសម្រួលគ្រប់យ៉ាង</p>
                    <p class="name">Meas Sovann</p>
                    <span class="position">Lecturer</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/Vannreth.jpg)">
                  </div>
                  <div class="text pl-4">
                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="fa fa-quote-left"></i>
                    </span>
                    <p>Excellent service and beautiful rooms. Highly recommended!</p>
                    <p class="name">ឡេង វណ្ណរ៉េត</p>
                    <span class="position">Member (Handle Coding)</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/lymey.jpg)">
                  </div>
                  <div class="text pl-4">
                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="fa fa-quote-left"></i>
                    </span>
                    <p>Great location and friendly staff. Will come back again!</p>
                    <p class="name">សំណាង លីមុី</p>
                    <span class="position">Member (Handle Coding)</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/Muninan.jpg)">
                  </div>
                  <div class="text pl-4">
                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="fa fa-quote-left"></i>
                    </span>
                    <p>Clean, comfortable, and affordable. Perfect for families.</p>
                    <p class="name">សំណាង មុនីណាន់</p>
                    <span class="position">Member (Handle Coding)</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/ThiaRah.jpg)">
                  </div>
                  <div class="text pl-4">
                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="fa fa-quote-left"></i>
                    </span>
                    <p>Staff were very helpful and the breakfast was delicious.</p>
                    <p class="name">ឡាំ ច័ន្ទសុធារ៉ា</p>
                    <span class="position">Member (Handle Slide)</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img" style="background-image: url(images/person_9.jpg)">
                  </div>
                  <div class="text pl-4">
                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="fa fa-quote-left"></i>
                    </span>
                    <p>Lovely atmosphere and great amenities. Will recommend to friends.</p>
                    <p class="name">គីត</p>
                    <span class="position">Member (Handle Slide)t</span>
                  </div>
                </div>
              </div>
    </section>

    <section class="ftco-section bg-light">
			<div class="container">
				<div class="row no-gutters">
					<div class="col-md-6 wrap-about ftco-animate">
	          <div class="heading-section">
	          	<div class="pl-md-5">
		            <h2 class="mb-2">What we offer</h2>
	            </div>
	          </div>
	          <div class="pl-md-5">
							<p>Let us make your next stay comfortable, easy, and memorable.</p>
							<div class="row">
		            <div class="services-2 col-lg-6 d-flex w-100">
		              <div class="icon d-flex justify-content-center align-items-center">
		            		<span class="flaticon-diet"></span>
		              </div>
		              <div class="media-body pl-3">
		                <h3 class="heading">Breakfast</h3>
		                <p>Wake Up to a Delicious Free Breakfast in Our Elegant Restaurant(2 people)</p>
		              </div>
		            </div> 
		            <div class="services-2 col-lg-6 d-flex w-100">
		              <div class="icon d-flex justify-content-center align-items-center">
		            		<span class="flaticon-workout"></span>
		              </div>
		              <div class="media-body pl-3">
		                <h3 class="heading">Hot Showers</h3>
		                <p>Experience our hot showers — the perfect way to unwind after a long day.</p>
		              </div>
		            </div>
		            <div class="services-2 col-lg-6 d-flex w-100">
		              <div class="icon d-flex justify-content-center align-items-center">
		            		<span class="flaticon-first"></span>
		              </div>
		              <div class="media-body pl-3">
		                <h3 class="heading">Air Conditioning</h3>
		                <p>2 Air Conditioning</p>
		              </div>
		            </div>
		            <div class="services-2 col-lg-6 d-flex w-100">
		              <div class="icon d-flex justify-content-center align-items-center">
		            		<span class="flaticon-first"></span>
		              </div>
		              <div class="media-body pl-3">
		                <h3 class="heading">Free Wifi</h3>
		                <p>Enjoy fast, free Wi-Fi throughout the hotel—stay connected anytime.</p>
		              </div>
		            </div> 
		            <div class="services-2 col-lg-6 d-flex w-100">
		              <div class="icon d-flex justify-content-center align-items-center">
		            		<span class="flaticon-first"></span>
		              </div>
		              <div class="media-body pl-3">
		                <h3 class="heading">Kitchen</h3>
		                <p>Enjoy the comfort of preparing your own meals with our fully equipped kitchen, perfect for long stays and families</p>
		              </div>
		            </div> 
		          </div>  
						</div>
					</div>
				</div>
			</div>
		</section>
		
<?php require "includes/footer.php";?>
  