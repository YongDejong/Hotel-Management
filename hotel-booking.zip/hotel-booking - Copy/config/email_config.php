<?php

// Email Configuration
define('SMTP_HOST', 'smtp.gmail.com');  // Replace with your SMTP host
define('SMTP_PORT', 587);               // Replace with your SMTP port
define('SMTP_USERNAME', '');            // Replace with your email
define('SMTP_PASSWORD', '');            // Replace with your email password or app-specific password
define('SMTP_FROM', 'noreply@hotelbooking.com');
define('SMTP_FROM_NAME', 'Hotel Booking');

// Function to send email using PHP's mail() function with proper headers
function sendEmail($to, $subject, $message) {
    $headers = array(
        'MIME-Version: 1.0',
        'Content-type: text/html; charset=UTF-8',
        'From: ' . SMTP_FROM_NAME . ' <' . SMTP_FROM . '>',
        'Reply-To: ' . SMTP_FROM,
        'X-Mailer: PHP/' . phpversion()
    );

    // Convert HTML message to proper format
    $htmlMessage = '
    <html>
    <head>
        <title>' . $subject . '</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <h2 style="color: #2c3e50;">' . $subject . '</h2>
            <div style="background: #f8f9fa; padding: 20px; border-radius: 5px;">
                ' . $message . '
            </div>
            <div style="margin-top: 20px; font-size: 12px; color: #666;">
                This is an automated email, please do not reply.
            </div>
        </div>
    </body>
    </html>';

    return mail($to, $subject, $htmlMessage, implode("\r\n", $headers));
} 